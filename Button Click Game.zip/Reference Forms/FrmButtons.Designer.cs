﻿namespace C__Practice__Windows_Form_App_What_I_know_so_far__
{
    partial class FrmButtons
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.GrpBox3 = new System.Windows.Forms.GroupBox();
            this.Btn30 = new System.Windows.Forms.Button();
            this.Btn29 = new System.Windows.Forms.Button();
            this.Btn28 = new System.Windows.Forms.Button();
            this.Btn27 = new System.Windows.Forms.Button();
            this.Btn26 = new System.Windows.Forms.Button();
            this.Btn25 = new System.Windows.Forms.Button();
            this.Btn24 = new System.Windows.Forms.Button();
            this.Btn23 = new System.Windows.Forms.Button();
            this.Btn22 = new System.Windows.Forms.Button();
            this.Btn21 = new System.Windows.Forms.Button();
            this.BtnExit = new System.Windows.Forms.Button();
            this.GrpBox1 = new System.Windows.Forms.GroupBox();
            this.Btn10 = new System.Windows.Forms.Button();
            this.Btn9 = new System.Windows.Forms.Button();
            this.Btn8 = new System.Windows.Forms.Button();
            this.Btn7 = new System.Windows.Forms.Button();
            this.Btn6 = new System.Windows.Forms.Button();
            this.Btn5 = new System.Windows.Forms.Button();
            this.Btn4 = new System.Windows.Forms.Button();
            this.Btn3 = new System.Windows.Forms.Button();
            this.Btn2 = new System.Windows.Forms.Button();
            this.Btn1 = new System.Windows.Forms.Button();
            this.Btn12 = new System.Windows.Forms.Button();
            this.Btn11 = new System.Windows.Forms.Button();
            this.Btn13 = new System.Windows.Forms.Button();
            this.Btn14 = new System.Windows.Forms.Button();
            this.Btn15 = new System.Windows.Forms.Button();
            this.Btn16 = new System.Windows.Forms.Button();
            this.Btn17 = new System.Windows.Forms.Button();
            this.Btn18 = new System.Windows.Forms.Button();
            this.Btn19 = new System.Windows.Forms.Button();
            this.Btn20 = new System.Windows.Forms.Button();
            this.GrpBox2 = new System.Windows.Forms.GroupBox();
            this.BtnStart = new System.Windows.Forms.Button();
            this.TxtBoxScore = new System.Windows.Forms.TextBox();
            this.LblScore = new System.Windows.Forms.Label();
            this.BtnResetStage1 = new System.Windows.Forms.Button();
            this.BtnLvlAllReset = new System.Windows.Forms.Button();
            this.BtnResetStage2 = new System.Windows.Forms.Button();
            this.BtnResetStage3 = new System.Windows.Forms.Button();
            this.BtnAddCount = new System.Windows.Forms.Button();
            this.btnSubCount = new System.Windows.Forms.Button();
            this.BtnPlayAgain = new System.Windows.Forms.Button();
            this.GrpBox3.SuspendLayout();
            this.GrpBox1.SuspendLayout();
            this.GrpBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // GrpBox3
            // 
            this.GrpBox3.AutoSize = true;
            this.GrpBox3.Controls.Add(this.Btn30);
            this.GrpBox3.Controls.Add(this.Btn29);
            this.GrpBox3.Controls.Add(this.Btn28);
            this.GrpBox3.Controls.Add(this.Btn27);
            this.GrpBox3.Controls.Add(this.Btn26);
            this.GrpBox3.Controls.Add(this.Btn25);
            this.GrpBox3.Controls.Add(this.Btn24);
            this.GrpBox3.Controls.Add(this.Btn23);
            this.GrpBox3.Controls.Add(this.Btn22);
            this.GrpBox3.Controls.Add(this.Btn21);
            this.GrpBox3.Location = new System.Drawing.Point(25, 294);
            this.GrpBox3.Name = "GrpBox3";
            this.GrpBox3.Size = new System.Drawing.Size(769, 103);
            this.GrpBox3.TabIndex = 8;
            this.GrpBox3.TabStop = false;
            this.GrpBox3.Text = "          Button Group 3";
            this.GrpBox3.Visible = false;
            // 
            // Btn30
            // 
            this.Btn30.AutoSize = true;
            this.Btn30.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn30.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn30.Location = new System.Drawing.Point(676, 19);
            this.Btn30.Name = "Btn30";
            this.Btn30.Size = new System.Drawing.Size(65, 65);
            this.Btn30.TabIndex = 2;
            this.Btn30.Text = "30";
            this.Btn30.UseVisualStyleBackColor = true;
            this.Btn30.Click += new System.EventHandler(this.Btn30_Click);
            // 
            // Btn29
            // 
            this.Btn29.AutoSize = true;
            this.Btn29.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn29.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn29.Location = new System.Drawing.Point(605, 19);
            this.Btn29.Name = "Btn29";
            this.Btn29.Size = new System.Drawing.Size(65, 65);
            this.Btn29.TabIndex = 2;
            this.Btn29.Text = "29";
            this.Btn29.UseVisualStyleBackColor = true;
            this.Btn29.Click += new System.EventHandler(this.Btn29_Click);
            // 
            // Btn28
            // 
            this.Btn28.AutoSize = true;
            this.Btn28.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn28.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn28.Location = new System.Drawing.Point(534, 19);
            this.Btn28.Name = "Btn28";
            this.Btn28.Size = new System.Drawing.Size(65, 65);
            this.Btn28.TabIndex = 2;
            this.Btn28.Text = "28";
            this.Btn28.UseVisualStyleBackColor = true;
            this.Btn28.Click += new System.EventHandler(this.Btn28_Click);
            // 
            // Btn27
            // 
            this.Btn27.AutoSize = true;
            this.Btn27.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn27.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn27.Location = new System.Drawing.Point(463, 19);
            this.Btn27.Name = "Btn27";
            this.Btn27.Size = new System.Drawing.Size(65, 65);
            this.Btn27.TabIndex = 2;
            this.Btn27.Text = "27";
            this.Btn27.UseVisualStyleBackColor = true;
            this.Btn27.Click += new System.EventHandler(this.Btn27_Click);
            // 
            // Btn26
            // 
            this.Btn26.AutoSize = true;
            this.Btn26.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn26.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn26.Location = new System.Drawing.Point(392, 19);
            this.Btn26.Name = "Btn26";
            this.Btn26.Size = new System.Drawing.Size(65, 65);
            this.Btn26.TabIndex = 2;
            this.Btn26.Text = "26";
            this.Btn26.UseVisualStyleBackColor = true;
            this.Btn26.Click += new System.EventHandler(this.Btn26_Click);
            // 
            // Btn25
            // 
            this.Btn25.AutoSize = true;
            this.Btn25.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn25.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn25.Location = new System.Drawing.Point(321, 19);
            this.Btn25.Name = "Btn25";
            this.Btn25.Size = new System.Drawing.Size(65, 65);
            this.Btn25.TabIndex = 2;
            this.Btn25.Text = "25";
            this.Btn25.UseVisualStyleBackColor = true;
            this.Btn25.Click += new System.EventHandler(this.Btn25_Click);
            // 
            // Btn24
            // 
            this.Btn24.AutoSize = true;
            this.Btn24.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn24.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn24.Location = new System.Drawing.Point(250, 19);
            this.Btn24.Name = "Btn24";
            this.Btn24.Size = new System.Drawing.Size(65, 65);
            this.Btn24.TabIndex = 2;
            this.Btn24.Text = "24";
            this.Btn24.UseVisualStyleBackColor = true;
            this.Btn24.Click += new System.EventHandler(this.Btn24_Click);
            // 
            // Btn23
            // 
            this.Btn23.AutoSize = true;
            this.Btn23.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn23.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn23.Location = new System.Drawing.Point(179, 19);
            this.Btn23.Name = "Btn23";
            this.Btn23.Size = new System.Drawing.Size(65, 65);
            this.Btn23.TabIndex = 2;
            this.Btn23.Text = "23";
            this.Btn23.UseVisualStyleBackColor = true;
            this.Btn23.Click += new System.EventHandler(this.Btn23_Click);
            // 
            // Btn22
            // 
            this.Btn22.AutoSize = true;
            this.Btn22.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn22.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn22.Location = new System.Drawing.Point(108, 19);
            this.Btn22.Name = "Btn22";
            this.Btn22.Size = new System.Drawing.Size(65, 65);
            this.Btn22.TabIndex = 2;
            this.Btn22.Text = "22";
            this.Btn22.UseVisualStyleBackColor = true;
            this.Btn22.Click += new System.EventHandler(this.Btn22_Click);
            // 
            // Btn21
            // 
            this.Btn21.AutoSize = true;
            this.Btn21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn21.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn21.Location = new System.Drawing.Point(37, 19);
            this.Btn21.Name = "Btn21";
            this.Btn21.Size = new System.Drawing.Size(65, 65);
            this.Btn21.TabIndex = 2;
            this.Btn21.Text = "21";
            this.Btn21.UseVisualStyleBackColor = true;
            this.Btn21.Click += new System.EventHandler(this.Btn21_Click);
            // 
            // BtnExit
            // 
            this.BtnExit.AutoSize = true;
            this.BtnExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.BtnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnExit.Location = new System.Drawing.Point(722, 403);
            this.BtnExit.Name = "BtnExit";
            this.BtnExit.Size = new System.Drawing.Size(66, 35);
            this.BtnExit.TabIndex = 0;
            this.BtnExit.Text = "Exit";
            this.BtnExit.UseVisualStyleBackColor = true;
            this.BtnExit.Click += new System.EventHandler(this.BtnExit_Click);
            // 
            // GrpBox1
            // 
            this.GrpBox1.AutoSize = true;
            this.GrpBox1.Controls.Add(this.Btn10);
            this.GrpBox1.Controls.Add(this.Btn9);
            this.GrpBox1.Controls.Add(this.Btn8);
            this.GrpBox1.Controls.Add(this.Btn7);
            this.GrpBox1.Controls.Add(this.Btn6);
            this.GrpBox1.Controls.Add(this.Btn5);
            this.GrpBox1.Controls.Add(this.Btn4);
            this.GrpBox1.Controls.Add(this.Btn3);
            this.GrpBox1.Controls.Add(this.Btn2);
            this.GrpBox1.Controls.Add(this.Btn1);
            this.GrpBox1.Location = new System.Drawing.Point(25, 76);
            this.GrpBox1.Name = "GrpBox1";
            this.GrpBox1.Size = new System.Drawing.Size(747, 103);
            this.GrpBox1.TabIndex = 3;
            this.GrpBox1.TabStop = false;
            this.GrpBox1.Text = "          Button Group 1";
            this.GrpBox1.Visible = false;
            // 
            // Btn10
            // 
            this.Btn10.AutoSize = true;
            this.Btn10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn10.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn10.Location = new System.Drawing.Point(676, 19);
            this.Btn10.Name = "Btn10";
            this.Btn10.Size = new System.Drawing.Size(65, 65);
            this.Btn10.TabIndex = 2;
            this.Btn10.Text = "10";
            this.Btn10.UseVisualStyleBackColor = true;
            this.Btn10.Click += new System.EventHandler(this.Btn10_Click);
            // 
            // Btn9
            // 
            this.Btn9.AutoSize = true;
            this.Btn9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn9.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn9.Location = new System.Drawing.Point(605, 19);
            this.Btn9.Name = "Btn9";
            this.Btn9.Size = new System.Drawing.Size(65, 65);
            this.Btn9.TabIndex = 2;
            this.Btn9.Text = "9";
            this.Btn9.UseVisualStyleBackColor = true;
            this.Btn9.Click += new System.EventHandler(this.Btn9_Click);
            // 
            // Btn8
            // 
            this.Btn8.AutoSize = true;
            this.Btn8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn8.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn8.Location = new System.Drawing.Point(534, 19);
            this.Btn8.Name = "Btn8";
            this.Btn8.Size = new System.Drawing.Size(65, 65);
            this.Btn8.TabIndex = 2;
            this.Btn8.Text = "8";
            this.Btn8.UseVisualStyleBackColor = true;
            this.Btn8.Click += new System.EventHandler(this.Btn8_Click);
            // 
            // Btn7
            // 
            this.Btn7.AutoSize = true;
            this.Btn7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn7.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn7.Location = new System.Drawing.Point(463, 19);
            this.Btn7.Name = "Btn7";
            this.Btn7.Size = new System.Drawing.Size(65, 65);
            this.Btn7.TabIndex = 2;
            this.Btn7.Text = "7";
            this.Btn7.UseVisualStyleBackColor = true;
            this.Btn7.Click += new System.EventHandler(this.Btn7_Click);
            // 
            // Btn6
            // 
            this.Btn6.AutoSize = true;
            this.Btn6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn6.Location = new System.Drawing.Point(392, 19);
            this.Btn6.Name = "Btn6";
            this.Btn6.Size = new System.Drawing.Size(65, 65);
            this.Btn6.TabIndex = 2;
            this.Btn6.Text = "6";
            this.Btn6.UseVisualStyleBackColor = true;
            this.Btn6.Click += new System.EventHandler(this.Btn6_Click);
            // 
            // Btn5
            // 
            this.Btn5.AutoSize = true;
            this.Btn5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn5.Location = new System.Drawing.Point(321, 19);
            this.Btn5.Name = "Btn5";
            this.Btn5.Size = new System.Drawing.Size(65, 65);
            this.Btn5.TabIndex = 2;
            this.Btn5.Text = "5";
            this.Btn5.UseVisualStyleBackColor = true;
            this.Btn5.Click += new System.EventHandler(this.Btn5_Click);
            // 
            // Btn4
            // 
            this.Btn4.AutoSize = true;
            this.Btn4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn4.Location = new System.Drawing.Point(250, 19);
            this.Btn4.Name = "Btn4";
            this.Btn4.Size = new System.Drawing.Size(65, 65);
            this.Btn4.TabIndex = 2;
            this.Btn4.Text = "4";
            this.Btn4.UseVisualStyleBackColor = true;
            this.Btn4.Click += new System.EventHandler(this.Btn4_Click);
            // 
            // Btn3
            // 
            this.Btn3.AutoSize = true;
            this.Btn3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn3.Location = new System.Drawing.Point(179, 19);
            this.Btn3.Name = "Btn3";
            this.Btn3.Size = new System.Drawing.Size(65, 65);
            this.Btn3.TabIndex = 2;
            this.Btn3.Text = "3";
            this.Btn3.UseVisualStyleBackColor = true;
            this.Btn3.Click += new System.EventHandler(this.Btn3_Click);
            // 
            // Btn2
            // 
            this.Btn2.AutoSize = true;
            this.Btn2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn2.Location = new System.Drawing.Point(108, 19);
            this.Btn2.Name = "Btn2";
            this.Btn2.Size = new System.Drawing.Size(65, 65);
            this.Btn2.TabIndex = 2;
            this.Btn2.Text = "2";
            this.Btn2.UseVisualStyleBackColor = true;
            this.Btn2.Click += new System.EventHandler(this.Btn2_Click);
            // 
            // Btn1
            // 
            this.Btn1.AutoSize = true;
            this.Btn1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn1.Location = new System.Drawing.Point(37, 19);
            this.Btn1.Name = "Btn1";
            this.Btn1.Size = new System.Drawing.Size(65, 65);
            this.Btn1.TabIndex = 2;
            this.Btn1.Text = "1";
            this.Btn1.UseVisualStyleBackColor = true;
            this.Btn1.Click += new System.EventHandler(this.Btn1_Click);
            // 
            // Btn12
            // 
            this.Btn12.AutoSize = true;
            this.Btn12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn12.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn12.Location = new System.Drawing.Point(108, 19);
            this.Btn12.Name = "Btn12";
            this.Btn12.Size = new System.Drawing.Size(65, 65);
            this.Btn12.TabIndex = 2;
            this.Btn12.Text = "12";
            this.Btn12.UseVisualStyleBackColor = true;
            this.Btn12.Click += new System.EventHandler(this.Btn12_Click);
            // 
            // Btn11
            // 
            this.Btn11.AutoSize = true;
            this.Btn11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn11.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn11.Location = new System.Drawing.Point(37, 19);
            this.Btn11.Name = "Btn11";
            this.Btn11.Size = new System.Drawing.Size(65, 65);
            this.Btn11.TabIndex = 2;
            this.Btn11.Text = "11";
            this.Btn11.UseVisualStyleBackColor = true;
            this.Btn11.Click += new System.EventHandler(this.Btn11_Click);
            // 
            // Btn13
            // 
            this.Btn13.AutoSize = true;
            this.Btn13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn13.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn13.Location = new System.Drawing.Point(179, 19);
            this.Btn13.Name = "Btn13";
            this.Btn13.Size = new System.Drawing.Size(65, 65);
            this.Btn13.TabIndex = 2;
            this.Btn13.Text = "13";
            this.Btn13.UseVisualStyleBackColor = true;
            this.Btn13.Click += new System.EventHandler(this.Btn13_Click);
            // 
            // Btn14
            // 
            this.Btn14.AutoSize = true;
            this.Btn14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn14.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn14.Location = new System.Drawing.Point(250, 19);
            this.Btn14.Name = "Btn14";
            this.Btn14.Size = new System.Drawing.Size(65, 65);
            this.Btn14.TabIndex = 2;
            this.Btn14.Text = "14";
            this.Btn14.UseVisualStyleBackColor = true;
            this.Btn14.Click += new System.EventHandler(this.Btn14_Click);
            // 
            // Btn15
            // 
            this.Btn15.AutoSize = true;
            this.Btn15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn15.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn15.Location = new System.Drawing.Point(321, 19);
            this.Btn15.Name = "Btn15";
            this.Btn15.Size = new System.Drawing.Size(65, 65);
            this.Btn15.TabIndex = 2;
            this.Btn15.Text = "15";
            this.Btn15.UseVisualStyleBackColor = true;
            this.Btn15.Click += new System.EventHandler(this.Btn15_Click);
            // 
            // Btn16
            // 
            this.Btn16.AutoSize = true;
            this.Btn16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn16.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn16.Location = new System.Drawing.Point(392, 19);
            this.Btn16.Name = "Btn16";
            this.Btn16.Size = new System.Drawing.Size(65, 65);
            this.Btn16.TabIndex = 2;
            this.Btn16.Text = "16";
            this.Btn16.UseVisualStyleBackColor = true;
            this.Btn16.Click += new System.EventHandler(this.Btn16_Click);
            // 
            // Btn17
            // 
            this.Btn17.AutoSize = true;
            this.Btn17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn17.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn17.Location = new System.Drawing.Point(463, 19);
            this.Btn17.Name = "Btn17";
            this.Btn17.Size = new System.Drawing.Size(65, 65);
            this.Btn17.TabIndex = 2;
            this.Btn17.Text = "17";
            this.Btn17.UseVisualStyleBackColor = true;
            this.Btn17.Click += new System.EventHandler(this.Btn17_Click);
            // 
            // Btn18
            // 
            this.Btn18.AutoSize = true;
            this.Btn18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn18.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn18.Location = new System.Drawing.Point(534, 19);
            this.Btn18.Name = "Btn18";
            this.Btn18.Size = new System.Drawing.Size(65, 65);
            this.Btn18.TabIndex = 2;
            this.Btn18.Text = "18";
            this.Btn18.UseVisualStyleBackColor = true;
            this.Btn18.Click += new System.EventHandler(this.Btn18_Click);
            // 
            // Btn19
            // 
            this.Btn19.AutoSize = true;
            this.Btn19.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn19.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn19.Location = new System.Drawing.Point(605, 19);
            this.Btn19.Name = "Btn19";
            this.Btn19.Size = new System.Drawing.Size(65, 65);
            this.Btn19.TabIndex = 2;
            this.Btn19.Text = "19";
            this.Btn19.UseVisualStyleBackColor = true;
            this.Btn19.Click += new System.EventHandler(this.Btn19_Click);
            // 
            // Btn20
            // 
            this.Btn20.AutoSize = true;
            this.Btn20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn20.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn20.Location = new System.Drawing.Point(676, 19);
            this.Btn20.Name = "Btn20";
            this.Btn20.Size = new System.Drawing.Size(65, 65);
            this.Btn20.TabIndex = 2;
            this.Btn20.Text = "20";
            this.Btn20.UseVisualStyleBackColor = true;
            this.Btn20.Click += new System.EventHandler(this.Btn20_Click);
            // 
            // GrpBox2
            // 
            this.GrpBox2.AutoSize = true;
            this.GrpBox2.Controls.Add(this.Btn13);
            this.GrpBox2.Controls.Add(this.Btn20);
            this.GrpBox2.Controls.Add(this.Btn11);
            this.GrpBox2.Controls.Add(this.Btn14);
            this.GrpBox2.Controls.Add(this.Btn19);
            this.GrpBox2.Controls.Add(this.Btn12);
            this.GrpBox2.Controls.Add(this.Btn15);
            this.GrpBox2.Controls.Add(this.Btn18);
            this.GrpBox2.Controls.Add(this.Btn16);
            this.GrpBox2.Controls.Add(this.Btn17);
            this.GrpBox2.Location = new System.Drawing.Point(25, 185);
            this.GrpBox2.Name = "GrpBox2";
            this.GrpBox2.Size = new System.Drawing.Size(747, 103);
            this.GrpBox2.TabIndex = 9;
            this.GrpBox2.TabStop = false;
            this.GrpBox2.Text = "          Button Group 2";
            this.GrpBox2.Visible = false;
            // 
            // BtnStart
            // 
            this.BtnStart.AutoSize = true;
            this.BtnStart.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnStart.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.BtnStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnStart.Location = new System.Drawing.Point(25, 403);
            this.BtnStart.Name = "BtnStart";
            this.BtnStart.Size = new System.Drawing.Size(66, 35);
            this.BtnStart.TabIndex = 11;
            this.BtnStart.Text = "Start";
            this.BtnStart.UseVisualStyleBackColor = true;
            this.BtnStart.Click += new System.EventHandler(this.BtnStart_Click);
            // 
            // TxtBoxScore
            // 
            this.TxtBoxScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtBoxScore.Location = new System.Drawing.Point(652, 12);
            this.TxtBoxScore.Name = "TxtBoxScore";
            this.TxtBoxScore.Size = new System.Drawing.Size(136, 26);
            this.TxtBoxScore.TabIndex = 12;
            this.TxtBoxScore.WordWrap = false;
            this.TxtBoxScore.TextChanged += new System.EventHandler(this.TxtBoxScore_TextChanged);
            // 
            // LblScore
            // 
            this.LblScore.AutoSize = true;
            this.LblScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblScore.Location = new System.Drawing.Point(590, 15);
            this.LblScore.Name = "LblScore";
            this.LblScore.Size = new System.Drawing.Size(56, 20);
            this.LblScore.TabIndex = 13;
            this.LblScore.Text = "Score";
            this.LblScore.Visible = false;
            // 
            // BtnResetStage1
            // 
            this.BtnResetStage1.AutoSize = true;
            this.BtnResetStage1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnResetStage1.Location = new System.Drawing.Point(346, 403);
            this.BtnResetStage1.Name = "BtnResetStage1";
            this.BtnResetStage1.Size = new System.Drawing.Size(136, 30);
            this.BtnResetStage1.TabIndex = 14;
            this.BtnResetStage1.Text = "Reset Stage 1";
            this.BtnResetStage1.UseVisualStyleBackColor = true;
            this.BtnResetStage1.Visible = false;
            this.BtnResetStage1.Click += new System.EventHandler(this.BtnResetStage1_Click);
            // 
            // BtnLvlAllReset
            // 
            this.BtnLvlAllReset.AutoSize = true;
            this.BtnLvlAllReset.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnLvlAllReset.Location = new System.Drawing.Point(630, 406);
            this.BtnLvlAllReset.Name = "BtnLvlAllReset";
            this.BtnLvlAllReset.Size = new System.Drawing.Size(92, 30);
            this.BtnLvlAllReset.TabIndex = 15;
            this.BtnLvlAllReset.Text = "Reset All";
            this.BtnLvlAllReset.UseVisualStyleBackColor = true;
            this.BtnLvlAllReset.Visible = false;
            this.BtnLvlAllReset.Click += new System.EventHandler(this.BtnLvlAllReset_Click);
            // 
            // BtnResetStage2
            // 
            this.BtnResetStage2.AutoSize = true;
            this.BtnResetStage2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnResetStage2.Location = new System.Drawing.Point(346, 403);
            this.BtnResetStage2.Name = "BtnResetStage2";
            this.BtnResetStage2.Size = new System.Drawing.Size(136, 30);
            this.BtnResetStage2.TabIndex = 16;
            this.BtnResetStage2.Text = "Reset Stage 2";
            this.BtnResetStage2.UseVisualStyleBackColor = true;
            this.BtnResetStage2.Visible = false;
            this.BtnResetStage2.Click += new System.EventHandler(this.BtnResetStage2_Click);
            // 
            // BtnResetStage3
            // 
            this.BtnResetStage3.AutoSize = true;
            this.BtnResetStage3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnResetStage3.Location = new System.Drawing.Point(346, 403);
            this.BtnResetStage3.Name = "BtnResetStage3";
            this.BtnResetStage3.Size = new System.Drawing.Size(136, 30);
            this.BtnResetStage3.TabIndex = 17;
            this.BtnResetStage3.Text = "Reset Stage 3";
            this.BtnResetStage3.UseVisualStyleBackColor = true;
            this.BtnResetStage3.Visible = false;
            this.BtnResetStage3.Click += new System.EventHandler(this.BtnResetStage3_Click);
            // 
            // BtnAddCount
            // 
            this.BtnAddCount.Location = new System.Drawing.Point(223, 403);
            this.BtnAddCount.Name = "BtnAddCount";
            this.BtnAddCount.Size = new System.Drawing.Size(72, 34);
            this.BtnAddCount.TabIndex = 18;
            this.BtnAddCount.Text = "Add Count";
            this.BtnAddCount.UseVisualStyleBackColor = true;
            this.BtnAddCount.Visible = false;
            this.BtnAddCount.Click += new System.EventHandler(this.BtnAddCount_Click);
            // 
            // btnSubCount
            // 
            this.btnSubCount.Location = new System.Drawing.Point(154, 406);
            this.btnSubCount.Name = "btnSubCount";
            this.btnSubCount.Size = new System.Drawing.Size(63, 32);
            this.btnSubCount.TabIndex = 19;
            this.btnSubCount.Text = "Sub Count";
            this.btnSubCount.UseVisualStyleBackColor = true;
            this.btnSubCount.Visible = false;
            this.btnSubCount.Click += new System.EventHandler(this.BtnSubCount_Click);
            // 
            // BtnPlayAgain
            // 
            this.BtnPlayAgain.AutoSize = true;
            this.BtnPlayAgain.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnPlayAgain.Location = new System.Drawing.Point(630, 406);
            this.BtnPlayAgain.Name = "BtnPlayAgain";
            this.BtnPlayAgain.Size = new System.Drawing.Size(103, 30);
            this.BtnPlayAgain.TabIndex = 20;
            this.BtnPlayAgain.Text = "Play Again";
            this.BtnPlayAgain.UseVisualStyleBackColor = true;
            this.BtnPlayAgain.Visible = false;
            this.BtnPlayAgain.Click += new System.EventHandler(this.BtnPlayAgain_Click);
            // 
            // FrmButtons
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.BtnPlayAgain);
            this.Controls.Add(this.btnSubCount);
            this.Controls.Add(this.BtnAddCount);
            this.Controls.Add(this.BtnResetStage3);
            this.Controls.Add(this.BtnResetStage2);
            this.Controls.Add(this.BtnLvlAllReset);
            this.Controls.Add(this.BtnResetStage1);
            this.Controls.Add(this.LblScore);
            this.Controls.Add(this.TxtBoxScore);
            this.Controls.Add(this.BtnStart);
            this.Controls.Add(this.GrpBox2);
            this.Controls.Add(this.BtnExit);
            this.Controls.Add(this.GrpBox1);
            this.Controls.Add(this.GrpBox3);
            this.Name = "FrmButtons";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Button Clicker";
            this.Load += new System.EventHandler(this.FrmButtons_Load);
            this.GrpBox3.ResumeLayout(false);
            this.GrpBox3.PerformLayout();
            this.GrpBox1.ResumeLayout(false);
            this.GrpBox1.PerformLayout();
            this.GrpBox2.ResumeLayout(false);
            this.GrpBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button BtnExit;
        private System.Windows.Forms.GroupBox GrpBox1;
        private System.Windows.Forms.Button Btn1;
        private System.Windows.Forms.Button Btn2;
        private System.Windows.Forms.Button Btn3;
        private System.Windows.Forms.Button Btn4;
        private System.Windows.Forms.Button Btn5;
        private System.Windows.Forms.Button Btn6;
        private System.Windows.Forms.Button Btn7;
        private System.Windows.Forms.Button Btn8;
        private System.Windows.Forms.Button Btn9;
        private System.Windows.Forms.Button Btn10;
        private System.Windows.Forms.GroupBox GrpBox2;
        private System.Windows.Forms.Button Btn11;
        private System.Windows.Forms.Button Btn12;
        private System.Windows.Forms.Button Btn13;
        private System.Windows.Forms.Button Btn14;
        private System.Windows.Forms.Button Btn15;
        private System.Windows.Forms.Button Btn16;
        private System.Windows.Forms.Button Btn17;
        private System.Windows.Forms.Button Btn18;
        private System.Windows.Forms.Button Btn19;
        private System.Windows.Forms.Button Btn20;
        private System.Windows.Forms.GroupBox GrpBox3;
        private System.Windows.Forms.Button Btn21;
        private System.Windows.Forms.Button Btn22;
        private System.Windows.Forms.Button Btn23;
        private System.Windows.Forms.Button Btn24;
        private System.Windows.Forms.Button Btn25;
        private System.Windows.Forms.Button Btn26;
        private System.Windows.Forms.Button Btn27;
        private System.Windows.Forms.Button Btn28;
        private System.Windows.Forms.Button Btn29;
        private System.Windows.Forms.Button Btn30;
        private System.Windows.Forms.Button BtnStart;
        private System.Windows.Forms.TextBox TxtBoxScore;
        private System.Windows.Forms.Label LblScore;
        private System.Windows.Forms.Button BtnResetStage1;
        private System.Windows.Forms.Button BtnLvlAllReset;
        private System.Windows.Forms.Button BtnResetStage2;
        private System.Windows.Forms.Button BtnResetStage3;
        private System.Windows.Forms.Button BtnAddCount;
        private System.Windows.Forms.Button btnSubCount;
        private System.Windows.Forms.Button BtnPlayAgain;
    }
}